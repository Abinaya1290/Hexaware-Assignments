package main;

import dao.ILoanRepository;
import dao.LoanRepositoryImpl;
import entity.CarLoan;
import entity.Customer;
import entity.HomeLoan;
import entity.Loan;
import exception.InvalidLoanException;

import java.util.List;
import java.util.Scanner;

public class LoanManagement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ILoanRepository loanRepo = new LoanRepositoryImpl();
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== Loan Management Menu ===");
            System.out.println("1. Apply Loan");
            System.out.println("2. Get All Loans");
            System.out.println("3. Get Loan by ID");
            System.out.println("4. Repay Loan");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    System.out.println("Enter Customer ID:");
                    int customerId = sc.nextInt();
                    sc.nextLine(); // consume newline
                    System.out.println("Loan Type (CarLoan / HomeLoan):");
                    String type = sc.nextLine();

                    System.out.println("Enter Principal Amount:");
                    double principal = sc.nextDouble();
                    System.out.println("Enter Interest Rate:");
                    double rate = sc.nextDouble();
                    System.out.println("Enter Loan Term (in months):");
                    int term = sc.nextInt();

                    Loan loan;
                    if (type.equalsIgnoreCase("CarLoan")) {
                        sc.nextLine(); // consume newline
                        System.out.println("Enter Car Model:");
                        String model = sc.nextLine();
                        System.out.println("Enter Car Value:");
                        int value = sc.nextInt();

                        CarLoan carLoan = new CarLoan();
                        carLoan.setCarModel(model);
                        carLoan.setCarValue(value);
                        loan = carLoan;
                    } else if (type.equalsIgnoreCase("HomeLoan")) {
                        sc.nextLine(); // consume newline
                        System.out.println("Enter Property Address:");
                        String address = sc.nextLine();
                        System.out.println("Enter Property Value:");
                        int value = sc.nextInt();

                        HomeLoan homeLoan = new HomeLoan();
                        homeLoan.setPropertyAddress(address);
                        homeLoan.setPropertyValue(value);
                        loan = homeLoan;
                    } else {
                        System.out.println("Invalid loan type.");
                        break;
                    }

                    Customer customer = new Customer();
                    customer.setCustomerId(customerId);
                    loan.setCustomer(customer);
                    loan.setPrincipalAmount(principal);
                    loan.setInterestRate(rate);
                    loan.setLoanTerm(term);
                    loan.setLoanType(type);
                    loan.setLoanStatus("PENDING");

                    boolean success = loanRepo.applyLoan(loan);
                    if (success) {
                        System.out.println("Loan applied successfully.");
                    } else {
                        System.out.println("Failed to apply for loan.");
                    }
                }

                case 2 -> {
                    List<Loan> loans = loanRepo.getAllLoan();
                    if (loans.isEmpty()) {
                        System.out.println("No loans found.");
                    } else {
                        for (Loan loan : loans) {
                            System.out.println(loan);
                        }
                    }
                }

                case 3 -> {
                    System.out.print("Enter Loan ID: ");
                    int loanId = sc.nextInt();
                    try {
                        Loan loan = loanRepo.getLoanById(loanId);
                        System.out.println(loan);
                    } catch (InvalidLoanException e) {
                        System.out.println("Loan not found.");
                    }
                }

                case 4 -> {
                    System.out.print("Enter Loan ID: ");
                    int loanId = sc.nextInt();
                    System.out.print("Enter Repayment Amount: ");
                    double amount = sc.nextDouble();

                    boolean repaid = loanRepo.loanRepayment(loanId, amount);
                    if (repaid) {
                        System.out.println("Loan repayment successful.");
                    } else {
                        System.out.println("Loan repayment failed.");
                    }
                }

                case 5 -> {
                    exit = true;
                    System.out.println("Exiting Loan Management System.");
                }

                default -> System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}
