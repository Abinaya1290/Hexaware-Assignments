package entity;

public class HomeLoan extends Loan {
	private String propertyAddress;
	private int propertyValue;
    public HomeLoan(String propertyAddress, int propertyValue) {
		super();
		this.propertyAddress = propertyAddress;
		this.propertyValue = propertyValue;
	}
	
    public HomeLoan() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    public String getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public int getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(int propertyValue) {
		this.propertyValue = propertyValue;
	}
	

    // Constructors, Getters, Setters, toString()
}

