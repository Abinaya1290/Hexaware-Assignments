package dao;

import entity.Loan;
import exception.InvalidLoanException;

import java.util.List;

public interface ILoanRepository {
    boolean applyLoan(Loan loan);

    double calculateInterest(int loanId) throws InvalidLoanException;
    double calculateInterest(double principal, double rate, int term);

    void loanStatus(int loanId);  // Changed from void to boolean for consistency

    double calculateEMI(int loanId) throws InvalidLoanException;
    double calculateEMI(double principal, double rate, int term);

    boolean loanRepayment(int loanId, double amount);  // Changed from void to boolean

    List<Loan> getAllLoans();  // Corrected method name

    Loan getLoanById(int loanId) throws InvalidLoanException;

	List<Loan> getAllLoan();
}
