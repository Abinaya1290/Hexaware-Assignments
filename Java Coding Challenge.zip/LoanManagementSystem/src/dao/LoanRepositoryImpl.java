package dao;

import entity.*;
import exception.InvalidLoanException;
import util.DBConnUtil;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LoanRepositoryImpl implements ILoanRepository {

    private static Connection connection;

    public LoanRepositoryImpl() {
    	try {
            connection = DBConnUtil.getDbConnection();
            if (connection == null) {
                throw new SQLException("Failed to establish a database connection.");
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
            System.out.println("Error: Unable to establish a connection to the database.");
        }
    }

    @Override
    public boolean applyLoan(Loan loan) {
        String query = "INSERT INTO loans (customerId, principalAmount, interestRate, loanTerm, loanType, loanStatus, carModel, carValue, propertyAddress, propertyValue) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, loan.getCustomer().getCustomerId());
            pstmt.setDouble(2, loan.getPrincipalAmount());
            pstmt.setDouble(3, loan.getInterestRate());
            pstmt.setInt(4, loan.getLoanTerm());
            pstmt.setString(5, loan.getLoanType());
            pstmt.setString(6, loan.getLoanStatus());

            // Subclass-specific fields
            if (loan instanceof CarLoan) {
                CarLoan carLoan = (CarLoan) loan;
                pstmt.setString(7, carLoan.getCarModel());
                pstmt.setInt(8, carLoan.getCarValue());
                pstmt.setNull(9, Types.VARCHAR); // propertyAddress
                pstmt.setNull(10, Types.INTEGER); // propertyValue
            } else if (loan instanceof HomeLoan) {
                HomeLoan homeLoan = (HomeLoan) loan;
                pstmt.setNull(7, Types.VARCHAR); // carModel
                pstmt.setNull(8, Types.INTEGER); // carValue
                pstmt.setString(9, homeLoan.getPropertyAddress());
                pstmt.setInt(10, homeLoan.getPropertyValue());
            } else {
                pstmt.setNull(7, Types.VARCHAR);
                pstmt.setNull(8, Types.INTEGER);
                pstmt.setNull(9, Types.VARCHAR);
                pstmt.setNull(10, Types.INTEGER);
            }

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error while applying loan");
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public double calculateInterest(int loanId) throws InvalidLoanException {
        String query = "SELECT principalAmount, interestRate, loanTerm FROM loans WHERE loanId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, loanId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                double principal = rs.getDouble("principalAmount");
                double rate = rs.getDouble("interestRate");
                int term = rs.getInt("loanTerm");
                return (principal * rate * term) / 12;
            } else {
                throw new InvalidLoanException("Loan not found with ID: " + loanId);
            }
        } catch (SQLException e) {
            System.out.println("Error while calculating interest");
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public double calculateInterest(double principal, double rate, int term) {
        return (principal * rate * term) / 12;
    }

    @Override
    public void loanStatus(int loanId) {
        String query = "SELECT creditScore FROM customers WHERE customerId = (SELECT customerId FROM loans WHERE loanId = ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, loanId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int creditScore = rs.getInt("creditScore");
                String updateQuery = "UPDATE loans SET loanStatus = ? WHERE loanId = ?";
                try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                    updateStmt.setString(1, creditScore > 650 ? "APPROVED" : "REJECTED");
                    updateStmt.setInt(2, loanId);
                    updateStmt.executeUpdate();
                }
            } else {
                throw new InvalidLoanException("Loan not found with ID: " + loanId);
            }
        } catch (SQLException | InvalidLoanException e) {
            System.out.println("Error while updating loan status");
            e.printStackTrace();
        }
    }

    @Override
    public double calculateEMI(int loanId) throws InvalidLoanException {
        String query = "SELECT principalAmount, interestRate, loanTerm FROM loans WHERE loanId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, loanId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double principal = rs.getDouble("principalAmount");
                double monthlyRate = rs.getDouble("interestRate") / 12 / 100;
                int term = rs.getInt("loanTerm");

                return (principal * monthlyRate * Math.pow(1 + monthlyRate, term)) /
                        (Math.pow(1 + monthlyRate, term) - 1);
            } else {
                throw new InvalidLoanException("Loan not found with ID: " + loanId);
            }
        } catch (SQLException e) {
            System.out.println("Error while calculating EMI");
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public double calculateEMI(double principal, double rate, int term) {
        double monthlyRate = rate / 12 / 100;
        return (principal * monthlyRate * Math.pow(1 + monthlyRate, term)) /
                (Math.pow(1 + monthlyRate, term) - 1);
    }

    @Override
    public boolean loanRepayment(int loanId, double amount) {
        try {
            double emi = calculateEMI(loanId);

            if (amount < emi) {
                System.out.println("Amount is less than EMI. Repayment rejected.");
                return false;
            }

            String updateQuery = "UPDATE loans SET principalAmount = principalAmount - ? WHERE loanId = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(updateQuery)) {
                pstmt.setDouble(1, amount);
                pstmt.setInt(2, loanId);
                pstmt.executeUpdate();
                return true;
            }
        } catch (SQLException | InvalidLoanException e) {
            System.out.println("Error while processing loan repayment");
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Loan> getAllLoan() {
        List<Loan> loanList = new ArrayList<>();
        String query = "SELECT * FROM loans";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                loanList.add(mapLoanFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching all loans");
            e.printStackTrace();
        }
        return loanList;
    }

    @Override
    public List<Loan> getAllLoans() {
        return getAllLoan();
    }

    @Override
    public Loan getLoanById(int loanId) throws InvalidLoanException {
        String query = "SELECT * FROM loans WHERE loanId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, loanId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return mapLoanFromResultSet(rs);
            } else {
                throw new InvalidLoanException("Loan not found with ID: " + loanId);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching loan by ID");
            e.printStackTrace();
            return null;
        }
    }

    private Loan mapLoanFromResultSet(ResultSet rs) throws SQLException {
        String loanType = rs.getString("loanType");
        Loan loan;

        if ("CarLoan".equalsIgnoreCase(loanType)) {
            CarLoan carLoan = new CarLoan();
            carLoan.setCarModel(rs.getString("carModel"));
            carLoan.setCarValue(rs.getInt("carValue"));
            loan = carLoan;
        } else if ("HomeLoan".equalsIgnoreCase(loanType)) {
            HomeLoan homeLoan = new HomeLoan();
            homeLoan.setPropertyAddress(rs.getString("propertyAddress"));
            homeLoan.setPropertyValue(rs.getInt("propertyValue"));
            loan = homeLoan;
        } else {
            loan = new Loan() {}; // anonymous subclass for generic Loan
        }

        loan.setLoanId(rs.getInt("loanId"));
        loan.setPrincipalAmount(rs.getDouble("principalAmount"));
        loan.setInterestRate(rs.getDouble("interestRate"));
        loan.setLoanTerm(rs.getInt("loanTerm"));
        loan.setLoanType(loanType);
        loan.setLoanStatus(rs.getString("loanStatus"));

        Customer customer = new Customer();
        customer.setCustomerId(rs.getInt("customerId"));
        loan.setCustomer(customer);

        return loan;
    }
}
