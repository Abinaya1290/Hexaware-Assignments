package dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.*;
import org.junit.*;
import entity.Customer;
import entity.Product;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;

public class OrderProcessorRepositoryTest {
    private static OrderProcessorRepository orderProcessor;
    private static Customer testCustomer;
    private static Product testProduct;
    
    @BeforeClass
    public static void setUpBeforeClass() {
        orderProcessor = new OrderProcessorRepositoryImpl();
        testCustomer = new Customer(0, "Rohit", "Rohit75gmail.com", "Rohit756");
        orderProcessor.createCustomer(testCustomer);
        testProduct = new Product(0, "Orange", 18.78, "Orange is Orange in colour", 20);
        orderProcessor.createProduct(testProduct);
    }
    
 
    
    @Test
    public void testCreateProduct() throws Exception {
        Product product = new Product(0, "Bread", 9.99, "Wheat Bread", 50);
        boolean result = orderProcessor.createProduct(product);
        assertTrue(result);
        assertTrue(product.getProductId() > 0);
        try {
            orderProcessor.deleteProduct(product.getProductId());
        } catch (ProductNotFoundException e) {
            fail("Failed to clean up test product");
        }
    }
    
    @Test
    public void testCreateCustomer() throws Exception {
        Customer customer = new Customer(0, "Rahul", "rahult@gmail.com", "rahul123");
        boolean result = orderProcessor.createCustomer(customer);
        assertTrue(result);
        assertTrue(customer.getCustomerId() > 0);
        try {
            orderProcessor.deleteCustomer(customer.getCustomerId());
        } catch (CustomerNotFoundException e) {
            fail("Failed to clean up test customer");
        }
    }
    
    @Test
    public void testAddToCart() {
        boolean result = orderProcessor.addToCart(testCustomer, testProduct, 1);
        assertTrue(result);
        List<Product> cartProducts = orderProcessor.getAllFromCart(testCustomer);
        assertFalse(cartProducts.isEmpty());
        assertEquals(testProduct.getProductId(), cartProducts.get(0).getProductId());
        orderProcessor.removeFromCart(testCustomer, testProduct);
    }
    
    @Test
    public void testPlaceOrder() {
        orderProcessor.addToCart(testCustomer, testProduct, 1);
        List<Map<Product, Integer>> productsWithQuantities = new ArrayList<>();
        Map<Product, Integer> item = new HashMap<>();
        item.put(testProduct, 1);
        productsWithQuantities.add(item);
        boolean result = orderProcessor.placeOrder(testCustomer, productsWithQuantities, "Address");
        assertTrue(result);
        List<Map<Product, Integer>> orders = orderProcessor.getOrdersByCustomer(testCustomer.getCustomerId());
        assertFalse(orders.isEmpty());
    }
    
    @Test(expected = ProductNotFoundException.class)
    public void testProductNotFoundException() throws ProductNotFoundException, Exception {
        orderProcessor.deleteProduct(-1);
    }
    
    @Test(expected = CustomerNotFoundException.class)
    public void testCustomerNotFoundException() throws CustomerNotFoundException, Exception {
        orderProcessor.deleteCustomer(-1);
    }
}
