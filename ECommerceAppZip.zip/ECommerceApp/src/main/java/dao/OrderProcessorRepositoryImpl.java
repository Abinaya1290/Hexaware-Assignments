package dao;

import entity.*;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;
import util.DBConnUtil;
import java.sql.*;
import java.util.*;
import java.util.Date;

public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {
    private Connection connection;

    public OrderProcessorRepositoryImpl() {
        try {
            this.connection = DBConnUtil.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database connection", e);
        }
    }

    @Override
    public boolean createProduct(Product product) {
        String sql = "INSERT INTO products (name, price, description, stockQuantity) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, product.getName());
            stmt.setDouble(2, product.getPrice());
            stmt.setString(3, product.getDescription());
            stmt.setInt(4, product.getStockQuantity());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                return false;
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    product.setProductId(generatedKeys.getInt(1));
                }
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean createCustomer(Customer customer) {
        String sql = "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPassword());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                return false;
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    customer.setCustomerId(generatedKeys.getInt(1));
                }
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteProduct(int productId) throws ProductNotFoundException, SQLException {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new ProductNotFoundException("Product with ID " + productId + " not found.");
            }
            return true;
        }
    }

    @Override
    public boolean deleteCustomer(int customerId) throws CustomerNotFoundException, SQLException {
        String sql = "DELETE FROM customers WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
            }
            return true;
        }
    }

    @Override
    public boolean addToCart(Customer customer, Product product, int quantity) {
        String sql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customer.getCustomerId());
            stmt.setInt(2, product.getProductId());
            stmt.setInt(3, quantity);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean removeFromCart(Customer customer, Product product) {
        String sql = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customer.getCustomerId());
            stmt.setInt(2, product.getProductId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Product> getAllFromCart(Customer customer) {
        List<Product> cartProducts = new ArrayList<>();
        String sql = "SELECT p.* FROM products p JOIN cart c ON p.product_id = c.product_id WHERE c.customer_id = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customer.getCustomerId());
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Product product = new Product(
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getString("description"),
                    rs.getInt("stockQuantity")
                );
                cartProducts.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cartProducts;
    }

    @Override
    public boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsWithQuantities, String shippingAddress) {
        try {
            connection.setAutoCommit(false);
            
            // Calculate total price
            double totalPrice = 0;
            for (Map<Product, Integer> item : productsWithQuantities) {
                for (Map.Entry<Product, Integer> entry : item.entrySet()) {
                    totalPrice += entry.getKey().getPrice() * entry.getValue();
                }
            }
            
            // Insert into orders table
            String orderSql = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (?, ?, ?, ?)";
            int orderId;
            try (PreparedStatement orderStmt = connection.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                orderStmt.setInt(1, customer.getCustomerId());
                orderStmt.setTimestamp(2, new Timestamp(new Date().getTime()));
                orderStmt.setDouble(3, totalPrice);
                orderStmt.setString(4, shippingAddress);
                
                orderStmt.executeUpdate();
                try (ResultSet generatedKeys = orderStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        orderId = generatedKeys.getInt(1);
                    } else {
                        connection.rollback();
                        return false;
                    }
                }
            }
            
            // Insert into order_items table
            String orderItemSql = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement orderItemStmt = connection.prepareStatement(orderItemSql)) {
                for (Map<Product, Integer> item : productsWithQuantities) {
                    for (Map.Entry<Product, Integer> entry : item.entrySet()) {
                        orderItemStmt.setInt(1, orderId);
                        orderItemStmt.setInt(2, entry.getKey().getProductId());
                        orderItemStmt.setInt(3, entry.getValue());
                        orderItemStmt.addBatch();
                    }
                }
                orderItemStmt.executeBatch();
            }
            
            // Clear the cart
            String clearCartSql = "DELETE FROM cart WHERE customer_id = ?";
            try (PreparedStatement clearCartStmt = connection.prepareStatement(clearCartSql)) {
                clearCartStmt.setInt(1, customer.getCustomerId());
                clearCartStmt.executeUpdate();
            }
            
            connection.commit();
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Map<Product, Integer>> getOrdersByCustomer(int customerId) {
        List<Map<Product, Integer>> orders = new ArrayList<>();
        String sql = "SELECT o.order_id, o.order_date, o.total_price, o.shipping_address, " +
                     "oi.product_id, oi.quantity, p.name, p.price, p.description, p.stockQuantity " +
                     "FROM orders o " +
                     "JOIN order_items oi ON o.order_id = oi.order_id " +
                     "JOIN products p ON oi.product_id = p.product_id " +
                     "WHERE o.customer_id = ? " +
                     "ORDER BY o.order_id";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            
            int currentOrderId = -1;
            Map<Product, Integer> currentOrder = null;
            
            while (rs.next()) {
                int orderId = rs.getInt("order_id");
                if (orderId != currentOrderId) {
                    if (currentOrder != null) {
                        orders.add(currentOrder);
                    }
                    currentOrder = new HashMap<>();
                    currentOrderId = orderId;
                }
                
                Product product = new Product(
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getString("description"),
                    rs.getInt("stockQuantity")
                );
                
                currentOrder.put(product, rs.getInt("quantity"));
            }
            
            if (currentOrder != null && !currentOrder.isEmpty()) {
                orders.add(currentOrder);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}