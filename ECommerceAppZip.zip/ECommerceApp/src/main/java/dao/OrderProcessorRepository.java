package dao;

import entity.Customer;
import entity.Product;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface OrderProcessorRepository {
    boolean createProduct(Product product);
    boolean createCustomer(Customer customer);
    boolean deleteProduct(int productId) throws ProductNotFoundException, SQLException;
    boolean deleteCustomer(int customerId) throws CustomerNotFoundException, SQLException;
    boolean addToCart(Customer customer, Product product, int quantity);
    boolean removeFromCart(Customer customer, Product product);
    List<Product> getAllFromCart(Customer customer);
    boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsWithQuantities, String shippingAddress);
    List<Map<Product, Integer>> getOrdersByCustomer(int customerId);
}